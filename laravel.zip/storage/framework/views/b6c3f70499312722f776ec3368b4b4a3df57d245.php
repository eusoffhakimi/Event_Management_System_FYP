<?php if(auth()->guard()->check()): ?>
    <?php echo $__env->make('layouts.navbars.navs.Sauth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php /**PATH /home/u349093193/domains/es2022821504.site/laravel/resources/views/layouts/navbars/Snavbar.blade.php ENDPATH**/ ?>