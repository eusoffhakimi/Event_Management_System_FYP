<?php $__env->startSection('content'); ?>
    <?php if(session('alert')): ?>
        <div class="alert alert-<?php echo e(session('alert')['type']); ?>" role="alert" style="margin-bottom: 15px;">
            <?php echo e(session('alert')['message']); ?>

        </div>
    <?php endif; ?>
    <div class="container py-4">
        <div class="row">
            <div class="col-lg-7 mx-auto d-flex justify-content-center flex-column">
                
                <h3 class="text-center text-white"><?php echo e($eventId->event_title); ?></h3>
                    <div class="card px-5 py-5"> <!-- card-body -->
                        <div class="mb-4">
                            <label class="text-white">Event Organizer</label>
                            <div class="input-group border-bottom border-primary">
                                <P><?php echo e($eventId->club->user->name); ?></P>
                            </div>
                        </div>
                        <div class="form-group mb-4 border-bottom border-primary">
                            <label class="text-white">Event Description</label>
                            <P><?php echo e($eventId->event_description); ?></P>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label class="text-white">Applicable Course</label>
                                <div class="input-group mb-4 border-bottom border-primary">
                                    <p><?php echo e($eventId->course->course_code); ?></p>
                                </div>
                            </div>
                            <div class="col-md-6 ps-2">
                                <label class="text-white">Venue</label>
                                <div class="input-group border-bottom border-primary">
                                    <p><?php echo e($eventId->event_venue); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label class="text-white">Capacity</label>
                                <div class="input-group mb-4 border-bottom border-primary">
                                    <p><?php echo e($eventId->event_capacity); ?></p>
                                </div>
                            </div>
                            <div class="col-md-6 ps-2">
                                <label class="text-white">Price</label>
                                <div class="input-group border-bottom border-primary">
                                    <p><?php if($eventId->event_price): ?>
                                            RM <?php echo e($eventId->event_price); ?>

                                        <?php else: ?>
                                            Free
                                        <?php endif; ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label class="text-white">Start Time</label>
                                <div class="input-group mb-4 border-bottom border-primary">
                                    <p><?php echo e(date('g.i A', strtotime($eventId->event_start_time))); ?></p>
                                </div>
                            </div>
                            <div class="col-md-6 ps-2">
                                <label class="text-white">End Time</label>
                                <div class="input-group border-bottom border-primary">
                                    <p><?php echo e(date('g.i A', strtotime($eventId->event_end_time))); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label class="text-white">Start Date</label>
                                <div class="input-group mb-4 border-bottom border-primary">
                                    <p><?php echo e(date('d F Y', strtotime($eventId->event_start_date))); ?></p>
                                </div>
                            </div>
                            <div class="col-md-6 ps-2">
                                <label class="text-white">End Date</label>
                                <div class="input-group border-bottom border-primary">
                                    <p><?php echo e(date('d F Y', strtotime($eventId->event_end_date))); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label class="text-white">Event Status</label>
                                <div class="input-group mb-4 border-bottom border-primary">
                                    <p><?php echo e($eventId->eventstatus->eventstatus_name); ?></p>
                                </div>
                            </div>
                            <div class="col-md-6 ps-2">
                                <label class="text-white">Event Category</label>
                                <div class="input-group border-bottom border-primary">
                                    <p><?php echo e($eventId->eventcategory->eventcategory_name); ?></p>
                                </div>
                            </div>
                        </div>
                        <?php if($eventId->club_id == auth()->user()->club->id): ?>
                            <div class="mb-4">
                                <label class="text-white">Event Verification Attendance Codes</label>
                                <div class="input-group border-bottom border-primary">
                                    <P><?php echo e($eventId->event_verification_code); ?></P>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php
                            $eventStartDateTime = \Carbon\Carbon::parse($eventId->event_start_date . ' ' . $eventId->event_start_time);
                        ?>
                        <?php if($eventId->club_id == auth()->user()->club->id && $eventStartDateTime >= $currentDateTime): ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <a class="btn bg-gradient-dark w-100" href="<?php echo e(route('CMyEventPage.index')); ?>">Back</a> <!-- <button type="submit" class="btn bg-gradient-dark w-100">Back</button> -->
                                </div>
                                <div class="col-md-6">
                                    <form role="form" method="POST" action="<?php echo e(route('CMyEventPage.blastEvent', $eventId->id)); ?>" autocomplete="off" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn bg-gradient-dark w-100">Blast</button> <!-- <button type="submit" class="btn bg-gradient-dark w-100">Back</button> -->
                                    </form>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <a class="btn bg-gradient-dark w-100" href="<?php echo e(route('CMyEventPage.index')); ?>">Back</a> <!-- <button type="submit" class="btn bg-gradient-dark w-100">Back</button> -->
                                </div>
                            </div>
                        <?php endif; ?>
                        
                    </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Clubmajor', ['page' => __('My Event'), 'pageSlug' => 'mevent'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\testevent\resources\views/CMyEventPage/showDetail.blade.php ENDPATH**/ ?>