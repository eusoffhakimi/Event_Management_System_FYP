<?php if(auth()->guard()->check()): ?>
    <?php echo $__env->make('layouts.navbars.navs.Sauth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\testevent\resources\views/layouts/navbars/Snavbar.blade.php ENDPATH**/ ?>