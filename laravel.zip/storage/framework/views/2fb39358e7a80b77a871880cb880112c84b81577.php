<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Event Management System - UiTM Campus Jasin</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="<?php echo e(asset('WeBuild/assets/img/favicon.png')); ?>" rel="icon">
  <link href="<?php echo e(asset('WeBuild/assets/img/apple-touch-icon.png')); ?>" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo e(asset('WeBuild/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('WeBuild/assets/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?php echo e(asset('WeBuild/assets/css/follow.css')); ?>" rel="stylesheet">

  <!-- =======================================================
  * Template Name: WeBuild
  * Updated: Jan 29 2024 with Bootstrap v5.3.2
  * Template URL: https://bootstrapmade.com/free-bootstrap-coming-soon-template-countdwon/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header">
    <div class="container-fluid d-flex justify-content-between align-items-center">

      <div class="logo">
        <h1 class="text-light"><a href="<?php echo e(url('/')); ?>"><span>ES</span></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        
      </div>

      <div class="contact-link float-right">
        <a href="#contact" class="scrollto">Contact Us</a>
        <?php if(Route::has('login')): ?>
            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->user_type == 0): ?>
                    <a href="<?php echo e(route('SJoinEvent.index')); ?>" class="scrollto">Dashboard</a>
                <?php else: ?>
                    <a href="<?php echo e(route('CMyEventPage.index')); ?>" class="scrollto">Dashboard</a>
                <?php endif; ?>
                
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="scrollto">Log In</a>

                <?php if(Route::has('register')): ?>
                    <a href="<?php echo e(route('register')); ?>" class="scrollto">Register</a>
                <?php endif; ?>
            <?php endif; ?>
        <?php endif; ?>
      </div>

    </div>
  </header><!-- End #header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div class="hero-container">
      <h1>Event System</h1>
      <h2>The Website Development is for Final Year Project</h2>
      <p><span class="typed" data-typed-items="Designer, Developer, Student, Hensem"></span></p>
      <div class="countdown" data-count="2024/8/5" data-template="%d days %h:%m:%s"></div>

      
      <div class="text-center" style="background-color: #4f92af; border: 0; padding: 10px 24px;">
        <a href="https://t.me/+GaxO_aNWVR00OWNl" style="color: #fff; text-decoration: none;">Get notified!</a>
      </div>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Contact Us Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title">
          <h2>Contact Me</h2>
        </div>

        <div class="row contact-info">

          <div class="col-md-4">
            <div class="contact-address">
              <i class="bi bi-geo-alt"></i>
              <h3>Address</h3>
              <address>Jalan Lembah Kesang 1/1-2, Kampung Seri Mendapat, 77300 Merlimau, Melaka</address>
            </div>
          </div>

          <div class="col-md-4">
            <div class="contact-phone">
              <i class="bi bi-phone"></i>
              <h3>Phone Number</h3>
              <p><a href="tel:+155895548855">012-210 4494</a></p>
            </div>
          </div>

          <div class="col-md-4">
            <div class="contact-email">
              <i class="bi bi-envelope"></i>
              <h3>Email</h3>
              <p><a href="mailto:eusoffhakimi2@gmail.com">eusoffhakimi2@gmail.com</a></p>
            </div>
          </div>

        </div>

        

      </div>
    </section><!-- End Contact Us Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>WeBuild</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/free-bootstrap-coming-soon-template-countdwon/ -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
      </div>
    </div>
  </footer><!-- End #footer -->

  <!-- Vendor JS Files -->
  <script src="<?php echo e(asset('WeBuild/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('WeBuild/assets/vendor/php-email-form/validate.js')); ?>"></script>
  <script src="<?php echo e(asset('WeBuild/assets/vendor/typed.js/typed.umd.js')); ?>"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo e(asset('WeBuild/assets/js/main.js')); ?>"></script>

</body>

</html>
<?php /**PATH /home/u349093193/domains/es2022821504.site/public_html/resources/views/hai.blade.php ENDPATH**/ ?>