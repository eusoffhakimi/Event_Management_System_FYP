<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="row">
            <div class="col-lg-7 mx-auto d-flex justify-content-center flex-column">
                <h3 class="text-center text-white">Create New Event</h3>
                <form role="form" method="POST" action="<?php echo e(route('CMyEventPage.storeEvent')); ?>" autocomplete="off" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card px-5 py-5"> <!-- card-body -->
                        <div class="mb-4">
                            <label class="text-white">Event Title</label>
                            <div class="input-group">
                                <input type="text" name="event_title" class="form-control" placeholder="" required="required">
                            </div>
                            <?php $__errorArgs = ['event_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger text-sm"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group mb-4">
                            <label class="text-white">Event Description</label>
                            <textarea name="event_description" class="form-control" id="message" rows="4" required="required"></textarea>
                            <?php $__errorArgs = ['event_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger text-sm"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label class="text-white">Applicable Course</label>
                                <div class="input-group mb-4">
                                    <select name="course_id" class="form-control" required="required">
                                        <option value="">-- Choose Course --</option>
                                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($course->id); ?>"><?php echo e($course->course_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['course_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger text-sm"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6 ps-2">
                                <label class="text-white">Venue</label>
                                <div class="input-group">
                                    <input type="text" name="event_venue" class="form-control" placeholder="" aria-label="" required="required">
                                </div>
                                <?php $__errorArgs = ['event_venue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger text-sm"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label class="text-white">Capacity</label>
                                <div class="input-group mb-4">
                                    <input type="number" name="event_capacity" class="form-control" placeholder="" aria-label="" required="required">
                                </div>
                                <?php $__errorArgs = ['event_capacity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger text-sm"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6 ps-2">
                                <label class="text-white">Payment</label>
                                <div class="input-group mb-4">
                                    <div class="btn-group" role="group" aria-label="Payment Options">
                                        <button type="button" class="btn btn-sm" value="0" onclick="toggleButtonClass(this)">Paid</button>
                                        <button type="button" class="btn btn-sm" value="1" onclick="toggleButtonClass(this)">Free</button>
                                    </div>
                                    <div style="display: none;">
                                        <input type="hidden" name="event_payment" class="form-control">
                                    </div>
                                </div>
                                <?php $__errorArgs = ['event_payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger text-sm"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="payment" style="display: none">
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="text-white">Price</label>
                                    <div class="input-group mb-4">
                                        <input type="number" name="event_price" class="form-control" placeholder="" aria-label="">
                                    </div>
                                </div>
                                <div class="col-md-6 ps-2">
                                    <label class="text-white">QR Picture</label>
                                    <div class="input-group">
                                        <input type="file" name="event_qr">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label class="text-white">Start Time</label>
                                <div class="input-group mb-4">
                                    <input type="time" name="event_start_time" class="form-control" value="" aria-label="" required="required">
                                </div>
                                <?php $__errorArgs = ['event_start_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger text-sm"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6 ps-2">
                                <label class="text-white">End Time</label>
                                <div class="input-group">
                                    <input type="time" name="event_end_time" class="form-control" value="" aria-label="" required="required">
                                </div>
                                <?php $__errorArgs = ['event_end_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger text-sm"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label class="text-white">Start Date</label>
                                <div class="input-group mb-4">
                                    <input type="date" name="event_start_date" class="form-control" placeholder="" aria-label="" required="required">
                                </div>
                                <?php $__errorArgs = ['event_start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger text-sm"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6 ps-2">
                                <label class="text-white">End Date</label>
                                <div class="input-group">
                                    <input type="date" name="event_end_date" class="form-control" placeholder="" aria-label="" required="required">
                                </div>
                                <?php $__errorArgs = ['event_end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger text-sm"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label class="text-white">Event Status</label>
                                <div class="input-group mb-4">
                                    <select name="eventstatus_id" class="form-control" required="required">
                                        <option value="">-- Choose Status --</option>
                                        <?php $__currentLoopData = $eventstatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventstatus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($eventstatus->id); ?>"><?php echo e($eventstatus->eventstatus_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['eventstatus_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger text-sm"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6 ps-2">
                                <label class="text-white">Event Category</label>
                                <div class="input-group">
                                    <select name="eventcategory_id" class="form-control" required="required">
                                        <option value="">-- Choose Category --</option>
                                        <?php $__currentLoopData = $eventcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($eventcategory->id); ?>"><?php echo e($eventcategory->eventcategory_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['eventcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger text-sm"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <button type="submit" class="btn bg-gradient-dark w-100">Create Event</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const paymentButtons = document.querySelectorAll('.btn-group button');
            const paymentContent = document.querySelector('.payment');
            const hiddenInput = document.querySelector('input[name="event_payment"]');
            const paymentInputs = paymentContent.querySelectorAll('input[type="number"], input[type="file"]');
            const qrInput = document.querySelector('input[name="event_qr"]');

            paymentButtons.forEach(function(button) {
                button.addEventListener('click', function() {
                    const value = button.value;
                    // const inputs = paymentContent.querySelectorAll('input[type="number"], input[type="file"]');
                    if (value === '1') {
                        paymentContent.style.display = 'none';
                        paymentInputs.forEach(function(input) {
                            input.removeAttribute('required');
                            input.value = null;
                        });
                        hiddenInput.value = 1;
                        if (qrInput.value !== '') { // If a file is uploaded for QR
                            qrInput.value = ''; // Clear QR input value
                        }
                    } else {
                        paymentContent.style.display = 'block';
                        paymentInputs.forEach(function(input) {
                            input.setAttribute('required', 'required');
                        });
                        hiddenInput.value = 0;
                    }
                });
            });
        });
    </script>
    <script>
        function toggleButtonClass(button) {
            // Remove the 'btn-primary' class from all buttons
            document.querySelectorAll('.btn-group button').forEach(function(btn) {
                btn.classList.remove('btn-primary');
            });

            // Add 'btn-primary' class to the clicked button
            button.classList.add('btn-primary');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Clubmajor', ['page' => __('My Event'), 'pageSlug' => 'mevent'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\testevent\resources\views/CMyEventPage/create.blade.php ENDPATH**/ ?>