<?php $__env->startSection('content'); ?>
    <?php if(session('alert')): ?>
        <div class="alert alert-<?php echo e(session('alert')['type']); ?>" role="alert" style="margin-bottom: 15px;">
            <?php echo e(session('alert')['message']); ?>

        </div>
    <?php endif; ?>
    <div class="container py-4">
        <div class="row">
            <div class="col-lg-7 mx-auto d-flex justify-content-center flex-column">
                <h3 class="text-center text-white"><?php echo e($eventId->event_title); ?></h3>
                <div class="card px-5 py-5"> <!-- card-body -->
                    <div class="mb-4">
                        <label class="text-white">Event Organizer</label>
                        <div class="input-group border-bottom border-primary">
                            <P><?php echo e($eventId->club->user->name); ?></P>
                        </div>
                    </div>
                    <div class="form-group mb-4 border-bottom border-primary">
                        <label class="text-white">Event Description</label>
                        <P><?php echo e($eventId->event_description); ?></P>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="text-white">Applicable Course</label>
                            <div class="input-group mb-4 border-bottom border-primary">
                                <p><?php echo e($eventId->course->course_code); ?></p>
                            </div>
                        </div>
                        <div class="col-md-6 ps-2">
                            <label class="text-white">Venue</label>
                            <div class="input-group border-bottom border-primary">
                                <p><?php echo e($eventId->event_venue); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="text-white">Capacity</label>
                            <div class="input-group mb-4 border-bottom border-primary">
                                <p><?php echo e($eventId->event_capacity); ?></p>
                            </div>
                        </div>
                        <div class="col-md-6 ps-2">
                            <label class="text-white">Price</label>
                            <div class="input-group border-bottom border-primary">
                                <p><?php if($eventId->event_price): ?>
                                        RM <?php echo e($eventId->event_price); ?>

                                    <?php else: ?>
                                        Free
                                    <?php endif; ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="text-white">Start Time</label>
                            <div class="input-group mb-4 border-bottom border-primary">
                                <p><?php echo e(date('g.i A', strtotime($eventId->event_start_time))); ?></p>
                            </div>
                        </div>
                        <div class="col-md-6 ps-2">
                            <label class="text-white">End Time</label>
                            <div class="input-group border-bottom border-primary">
                                <p><?php echo e(date('g.i A', strtotime($eventId->event_end_time))); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="text-white">Start Date</label>
                            <div class="input-group mb-4 border-bottom border-primary">
                                <p><?php echo e(date('d F Y', strtotime($eventId->event_start_date))); ?></p>
                            </div>
                        </div>
                        <div class="col-md-6 ps-2">
                            <label class="text-white">End Date</label>
                            <div class="input-group border-bottom border-primary">
                                <p><?php echo e(date('d F Y', strtotime($eventId->event_end_date))); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="text-white">Event Status</label>
                            <div class="input-group mb-4 border-bottom border-primary">
                                <p><?php echo e($eventId->eventstatus->eventstatus_name); ?></p>
                            </div>
                        </div>
                        <div class="col-md-6 ps-2">
                            <label class="text-white">Event Category</label>
                            <div class="input-group border-bottom border-primary">
                                <p><?php echo e($eventId->eventcategory->eventcategory_name); ?></p>
                            </div>
                        </div>
                    </div>
                    <?php if($ratingExists): ?>
                        <div class="mb-4">
                            <label class="text-white">Event Rating</label>
                            <div class="input-group border-bottom border-primary">
                                <P><?php echo e($ratingValue); ?>/5</P>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <a class="btn bg-gradient-dark w-100" href="<?php echo e(route('SJoinEvent.index')); ?>">Back</a>
                            </div>
                        </div>
                    <?php else: ?>
                        <form role="form" method="POST" action="<?php echo e(route('SJoinEvent.storeRating', $eventId->id)); ?>" autocomplete="off"> <!-- id="contact-form" -->
                            <?php echo csrf_field(); ?>
                            <div class="mb-4">
                                <label class="text-white">Event Rating</label>
                                <div class="input-group">
                                    
                                    <select name="rating_event" class="form-control" required="required">
                                        <option value="">-- Choose Scale Rating --</option>
                                        <option value="1">1 - Poor</option>
                                        <option value="2">2 - Unsatisfactory</option>
                                        <option value="3">3 - Satisfactory</option>
                                        <option value="4">4 - Very Satisfactory</option>
                                        <option value="5">5 - Outstanding</option>
                                    </select>
                                    <?php $__errorArgs = ['rating_event'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger text-sm"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <button type="submit" class="btn bg-gradient-dark w-100">Submit Rating</button>
                                </div>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.StudentMajor', ['page' => __('Join Event'), 'pageSlug' => 'jevent'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\testevent\resources\views/SJoinEvent/editRating.blade.php ENDPATH**/ ?>