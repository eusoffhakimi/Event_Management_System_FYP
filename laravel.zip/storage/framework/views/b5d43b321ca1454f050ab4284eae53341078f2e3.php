<?php $__env->startSection('content'); ?>
    <?php if(session('alert')): ?>
        <div class="alert alert-<?php echo e(session('alert')['type']); ?>" role="alert" style="margin-bottom: 15px;">
            <?php echo e(session('alert')['message']); ?>

        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card ">
                <div class="card-header">
                    <div class="row">
                        <div class="col-9">
                            <h4 class="card-title">Participant</h4>
                        </div>
                        <div class="col-3 text-right">
                            <h4 class="card-title"><?php echo e($event->participant->count()); ?>/<?php echo e($event->event_capacity); ?></h4>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="">
                        <table class="table tablesorter " id="">
                            <thead class=" text-primary">
                                <tr>
                                    <th scope="col">Num</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Course</th>
                                    <th scope="col">Phone Number</th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $thereReceipt = $participant->payment !== null;
                                    ?>
                                    <tr>
                                        <td><?php echo e(++$number); ?></td>
                                        <td><?php echo e($participant->student->user->name); ?></td>
                                        <td><?php echo e($participant->student->course->course_code); ?></td> <!-- <a href="mailto:admin@black.com">admin@black.com</a> -->
                                        <td><?php echo e($participant->student->student_phone_number); ?></td>
                                        <td class="pull-right">
                                            <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                                                <?php if($thereReceipt): ?>
                                                    <a class="btn btn-info text-white px-3 mb-0" href="#" id="modalBtn">View Receipt</a>
                                                <?php endif; ?>
                                                <form method="POST" action="<?php echo e(route('CMyEventPage.deleteParticipant', $participant->id)); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger text-white px-3 mb-0" href="#">Drop</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Modal -->
        <div class="modal" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Receipt</h5>
                    </div>
                    <div class="modal-body">
                        <?php if(isset($participant->payment->payment_receipt)): ?>
                            <img class="avatar" src="<?php echo e(asset('picture/receipt/' . $participant->payment->payment_receipt)); ?>" alt="">
                        <?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn-close btn bg-gradient-dark" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <script>
        // Get the modal
        var modal = document.getElementById('exampleModal');

        // Get the button that opens the modal
        var btn = document.getElementById("modalBtn");

        // When the user clicks the button, open the modal
        btn.addEventListener("click", function() {
            modal.style.display = "block";
        });

        // When the user clicks on <span> (x), close the modal
        modal.querySelector(".btn-close").addEventListener("click", function() {
            modal.style.display = "none";
        });

        // When the user clicks anywhere outside of the modal, close it
        window.addEventListener("click", function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        });
    </script>

    <!-- Script for search functionality -->
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var searchInput = document.getElementById('inlineFormInputGroup');

            searchInput.addEventListener('input', function() {
                var searchTerm = this.value.trim().toLowerCase();
                var participantRows = document.querySelectorAll('tbody tr');

                participantRows.forEach(function(row) {
                    var name = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
                    var courseCode = row.querySelector('td:nth-child(3)').textContent.toLowerCase();
                    var phoneNumber = row.querySelector('td:nth-child(4)').textContent.toLowerCase();

                    if (name.includes(searchTerm) || courseCode.includes(searchTerm) || phoneNumber.includes(searchTerm)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Clubmajor', ['page' => __('My Event'), 'pageSlug' => 'mevent'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\testevent\resources\views/CMyEventPage/editParticipant.blade.php ENDPATH**/ ?>