<div class="sidebar">
    <div class="sidebar-wrapper">
        <div class="logo">
            <a href="<?php echo e(url('/')); ?>" class="simple-text logo-mini"><?php echo e(__('ES')); ?></a>
            <a href="<?php echo e(url('/')); ?>" class="simple-text logo-normal"><?php echo e(__('Event System')); ?></a>
        </div>
        <ul class="nav">
            <li <?php if($pageSlug == 'jevent'): ?> class="active " <?php endif; ?>>
                <a href="<?php echo e(route('SJoinEvent.index')); ?>">
                    <i class="tim-icons icon-bell-55"></i>
                    <p><?php echo e(__('Join Event')); ?></p>
                </a>
            </li>
            
            <li <?php if($pageSlug == 'profile'): ?> class="active " <?php endif; ?>>
                <a href="<?php echo e(route('SProfilePage.edit')); ?>">
                    <i class="tim-icons icon-single-02"></i>
                    <p><?php echo e(__('Profile')); ?></p>
                </a>
            </li>
            <li class=" <?php echo e($pageSlug == 'logout' ? 'active' : ''); ?> bg-info">
                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();  document.getElementById('logout-form').submit();">
                    <i class="tim-icons icon-spaceship"></i>
                    <p><?php echo e(__('Logout')); ?></p>
                </a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH /home/u349093193/domains/es2022821504.site/laravel/resources/views/layouts/navbars/Ssidebar.blade.php ENDPATH**/ ?>