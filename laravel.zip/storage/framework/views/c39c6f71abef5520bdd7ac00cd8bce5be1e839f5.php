<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8">
            <?php if(session('alert')): ?>
                <div class="alert alert-<?php echo e(session('alert')['type']); ?>" role="alert" style="margin-bottom: 15px;">
                    <?php echo e(session('alert')['message']); ?>

                </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h5 class="title"><?php echo e(__('Edit Profile')); ?></h5>
                </div>
                <form method="post" action="<?php echo e(route('SProfilePage.updateProfile')); ?>" autocomplete="off">
                    <div class="card-body">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>

                            <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                <label><?php echo e(__('Name')); ?></label>
                                <input type="text" name="name" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e(old('name', auth()->user()->name)); ?>">
                                
                            </div>

                            <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                                <label><?php echo e(__('Email address')); ?></label>
                                <input type="email" name="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Email address')); ?>" value="<?php echo e(old('email', auth()->user()->email)); ?>">
                                
                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-fill btn-success"><?php echo e(__('Save')); ?></button>
                    </div>
                </form>
            </div>

            <div class="card">
                <div class="card-header">
                    <h5 class="title"><?php echo e(__('Password')); ?></h5>
                </div>
                <form method="post" action="<?php echo e(route('SProfilePage.updatePassword')); ?>" autocomplete="off">
                    <div class="card-body">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>

                        <div class="form-group<?php echo e($errors->has('old_password') ? ' has-danger' : ''); ?>">
                            <label><?php echo e(__('Current Password')); ?></label>
                            <input type="password" name="old_password" class="form-control<?php echo e($errors->has('old_password') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Current Password')); ?>" value="" required>
                            
                            <?php if($errors->has('old_password')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('old_password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                            <label><?php echo e(__('New Password')); ?></label>
                            <input type="password" name="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('New Password')); ?>" value="" required>
                            
                            <?php if($errors->has('password')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label><?php echo e(__('Confirm New Password')); ?></label>
                            <input type="password" name="password_confirmation" class="form-control" placeholder="<?php echo e(__('Confirm New Password')); ?>" value="" required>
                            <?php if($errors->has('password_confirmation')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-fill btn-success"><?php echo e(__('Change password')); ?></button>
                    </div>
                </form>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card card-user">
                <div class="card-body">
                    <p class="card-text">
                        <div class="author">
                            <div class="block block-one"></div>
                            <div class="block block-two"></div>
                            <div class="block block-three"></div>
                            <div class="block block-four"></div>
                            <a id="modalBtn" href="#">
                                <?php if(auth()->user()->student->student_picture): ?>
                                    <img class="avatar" src="<?php echo e(asset('picture/student/' . auth()->user()->student->student_picture)); ?>" alt="">
                                <?php else: ?>
                                    <img class="avatar" src="<?php echo e(asset('ForDesign/resources/assets/img/anime3.png')); ?>" alt=""> <!-- "<?php echo e(asset('black')); ?>/img/emilyz.jpg" -->
                                <?php endif; ?>
                                <h5 class="title"><?php echo e(auth()->user()->name); ?></h5>
                            </a>
                            <p class="description">
                                <?php echo e(auth()->user()->student->student_matric); ?>

                            </p>
                        </div>
                    </p>
                    <form method="post" action="<?php echo e(route('SProfilePage.updateDetail')); ?>" autocomplete="off">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>

                        <div class="form-group">
                            <label><?php echo e(__('Course Code')); ?></label>
                            <input type="text" name="" class="form-control text-white" placeholder="" value="<?php echo e(old('course_id', auth()->user()->student->course->course_name ?? '')); ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label><?php echo e(__('Phone Number')); ?></label>
                            <input type="text" name="student_phone_number" class="form-control" placeholder="" value="<?php echo e(old('student_phone_number', auth()->user()->student->student_phone_number ?? '')); ?>" required>
                            
                        </div>

                        <div class="form-group">
                            <label><?php echo e(__('Event Category Preferences')); ?></label>
                            <select name="eventcategory_id" class="form-control">
                                <option value="">-- Choose Category --</option>
                                <?php $__currentLoopData = $eventcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($eventcategory->id); ?>" <?php echo e(old('eventcategory_id', (auth()->user()->student->eventcategory_id ?? null)) == $eventcategory->id ? 'selected' : ''); ?>>
                                        <?php echo e($eventcategory->eventcategory_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['eventcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger text-sm"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label><?php echo e(__('Hobby')); ?></label>
                            <select name="hobby_id" class="form-control">
                                <option value="">-- Choose Hobby --</option>
                                <?php $__currentLoopData = $hobbies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hobby): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($hobby->id); ?>" <?php echo e(old('hobby_id', (auth()->user()->student->hobby_id ?? null)) == $hobby->id ? 'selected' : ''); ?>>
                                        <?php echo e($hobby->hobby_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['hobby_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger text-sm"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="card-footer text-center">
                            <button type="submit" class="btn btn-fill btn-success"><?php echo e(__('Save')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Picture</h5>
                </div>
                <form method="post" action="<?php echo e(route('SProfilePage.updatePicture')); ?>" autocomplete="off" enctype="multipart/form-data">
                    <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        
                        <div class="ps-2">
                            <label>Submit New Picture</label>
                            <div class="input-group">
                                <input type="file" name="student_picture">
                            </div>
                            <?php $__errorArgs = ['student_picture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger text-sm"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn-close btn bg-gradient-dark" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn bg-gradient-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Get the modal
        var modal = document.getElementById('exampleModal');

        // Get the button that opens the modal
        var btn = document.getElementById("modalBtn");

        // When the user clicks the button, open the modal
        btn.addEventListener("click", function() {
            modal.style.display = "block";
        });

        // When the user clicks on <span> (x), close the modal
        modal.querySelector(".btn-close").addEventListener("click", function() {
            modal.style.display = "none";
        });

        // When the user clicks anywhere outside of the modal, close it
        window.addEventListener("click", function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Studentmajor', ['page' => __('Profile'), 'pageSlug' => 'profile'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u349093193/domains/es2022821504.site/laravel/resources/views/SProfilePage/edit.blade.php ENDPATH**/ ?>