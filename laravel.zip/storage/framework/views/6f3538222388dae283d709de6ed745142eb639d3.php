


    <div class="alert alert-danger">
        <strong>Error:</strong> The required database table 'courses' is missing. Please contact the administrator.
    </div>

<?php /**PATH C:\laragon\www\testevent\resources\views/error/database_missing_course_table.blade.php ENDPATH**/ ?>