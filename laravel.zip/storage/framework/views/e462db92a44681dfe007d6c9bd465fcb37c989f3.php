

<div class="sidebar">
    <div class="sidebar-wrapper">
        <div class="logo">
            <a href="<?php echo e(url('/')); ?>" class="simple-text logo-mini"><?php echo e(__('ES')); ?></a>
            <a href="<?php echo e(url('/')); ?>" class="simple-text logo-normal"><?php echo e(__('Event System')); ?></a>
        </div>
        <ul class="nav">
            <li <?php if($pageSlug == 'mevent'): ?> class="active " <?php endif; ?>>
                <a href="<?php echo e(route('CMyEventPage.index')); ?>">
                    <i class="tim-icons icon-bell-55"></i>
                    <p><?php echo e(__('My Event')); ?></p>
                </a>
            </li>
            <li <?php if($pageSlug == 'cevent'): ?> class="active " <?php endif; ?>>
                <a href="<?php echo e(route('CMyEventPage.resultCollaborative')); ?>">
                    <i class="tim-icons icon-bullet-list-67"></i>
                    <p><?php echo e(__('Recommending Event')); ?></p>
                </a>
            </li>
            <li <?php if($pageSlug == 'profile'): ?> class="active " <?php endif; ?>>
                <a href="<?php echo e(route('CProfilePage.edit')); ?>">
                    <i class="tim-icons icon-single-02"></i>
                    <p><?php echo e(__('Profile')); ?></p>
                </a>
            </li>
            <li class=" <?php echo e($pageSlug == 'logout' ? 'active' : ''); ?> bg-info">
                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();  document.getElementById('logout-form').submit();">
                    <i class="tim-icons icon-spaceship"></i>
                    <p><?php echo e(__('Logout')); ?></p>
                </a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH C:\laragon\www\testevent\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>