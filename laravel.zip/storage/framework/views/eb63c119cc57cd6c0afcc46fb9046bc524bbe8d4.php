<footer class="footer">
    <div class="container-fluid">
        
        <div class="copyright">
            &copy; <?php echo e(now()->year); ?> <?php echo e(__('made with')); ?> <i class="tim-icons icon-heart-2"></i> <?php echo e(__('by')); ?>

            <a href="https://creative-tim.com" target="_blank"><?php echo e(__('Creative Tim')); ?></a> &amp;
            <a href="https://updivision.com" target="_blank"><?php echo e(__('Updivision')); ?></a> <?php echo e(__('for a better web')); ?>.
        </div>
        <div class="copyright">
            <?php echo e(__('Every Informations are for Final Year Project (Academic Purposes) Only. Thank You Very Much !!!')); ?>

        </div>
    </div>
</footer>
<?php /**PATH /home/u349093193/domains/es2022821504.site/laravel/resources/views/layouts/footer.blade.php ENDPATH**/ ?>