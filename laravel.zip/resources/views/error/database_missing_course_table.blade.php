<div class="alert alert-danger">
    <strong>Error:</strong> The required database table 'courses' is missing. Please contact the administrator.
</div>
