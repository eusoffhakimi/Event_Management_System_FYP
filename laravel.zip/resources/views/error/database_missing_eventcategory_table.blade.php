<div class="alert alert-danger">
    <strong>Error:</strong> The required database table 'eventcategory' is missing. Please contact the administrator.
</div>
