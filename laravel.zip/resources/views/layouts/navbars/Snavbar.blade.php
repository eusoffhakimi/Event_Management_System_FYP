@auth()
    @include('layouts.navbars.navs.Sauth')
@endauth
